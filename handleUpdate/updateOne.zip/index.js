'use strict';

const { DynamoDBClient } = require("@aws-sdk/client-dynamodb");
const { UpdateCommand, DynamoDBDocumentClient } = require("@aws-sdk/lib-dynamodb");

const client = new DynamoDBClient({});
const docClient = DynamoDBDocumentClient.from(client);

exports.handler = async (event) => {
  let response = {}

  if ( event.id === undefined || event.id === null || ( event.title === null && event.value === null && event.rarity === null )) {
    response = {
      statusCode: 500,
      body: { "error": "Not enough information to complete update." },
    };
  }

  let updateExpression = "set "

  const { id, title, bookValue, rarity } = event;

  const updateValues = {};

  if ( title ) {
    updateExpression += 'title = :title, ';
    updateValues[':title'] = title
  };
  if ( bookValue ) {
    updateExpression += 'bookValue = :bookValue, ';
    updateValues[':bookValue'] = parseInt(bookValue)
  };
  if ( rarity ) {
    updateExpression += 'rarity = :rarity';
    updateValues[':rarity'] = rarity
  };

  const command = new UpdateCommand({
    TableName: "comics",
    Key: {
      id: parseInt(id),
    },
    UpdateExpression: updateExpression,
    ExpressionAttributeValues: updateValues,
    ReturnValues: "ALL_NEW",
  });
  
  const result = await docClient.send(command);

  response = {
    statusCode: 200,
    body: JSON.stringify({ id, title, bookValue, rarity }),
  };
  return response;
};
